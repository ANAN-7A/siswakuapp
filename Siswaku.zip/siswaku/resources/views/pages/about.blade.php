@extends('template')

@section('main')
	<div id="about">
		<h2>About</h2>
		<p>aplikasi <strong>LaravelApp</strong></p> dibuat sebagai latihan untuk mempelajari Laravel
	</div>
@stop