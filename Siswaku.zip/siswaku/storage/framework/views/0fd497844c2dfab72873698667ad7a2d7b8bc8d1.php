<div id="footer">
	<p>&copy; 2019 SiswakuApp</p>
</div><?php /**PATH C:\xampp\htdocs\siswaku\resources\views/footer.blade.php ENDPATH**/ ?>