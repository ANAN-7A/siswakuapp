<?php $__env->startSection('main'); ?>
	<div id="about">
		<h2>About</h2>
		<p>aplikasi <strong>LaravelApp</strong></p> dibuat sebagai latihan untuk mempelajari Laravel
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siswaku\resources\views/pages/about.blade.php ENDPATH**/ ?>